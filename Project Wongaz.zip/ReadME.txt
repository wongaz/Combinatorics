To Run the Program For 
min arcs there 2 todos. 
Just Change the file directory/location 
of the .gr file. 

The program generates 
all the arrays necessary to the program 
after it reads in the file no need to stop 
change which test implementation you are doing
Each CallToLaunch represents one of the algorithms:
	a ---- Generics
	b ---- Modified Queue
	c ---- Modified Stack
	d ---- Modified Dequeue
	e ---- Modified Min Dist
There is check if you want that will iterate over all the
update Node Arrays and compareWeights for consistency.

If a cycle occurs it will stop all process and print out 
the negative cycle
   